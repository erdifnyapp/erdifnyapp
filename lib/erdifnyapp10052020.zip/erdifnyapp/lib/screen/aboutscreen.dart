import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:erdifny/utils/color_pallet.dart';

class AboutScreen extends StatefulWidget {
  AboutScreen({Key key}) : super(key: key);

  @override
  _AboutScreenState createState() {
    return _AboutScreenState();
  }
}

class _AboutScreenState extends State<AboutScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      body: Container(
        decoration: BoxDecoration(
          color: Colors.white,
        ),
        child: _appBody(),
      ),
    );
  }

  _appBody() {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
      ),
      child: Stack(children: <Widget>[

        SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            children: <Widget>[

              SizedBox(height: 160,),
              Center(
                child: Image.asset(
                  "assets/images/logo.png",
                  width: 130,
                  height: 130,
                ),
              ),

              SizedBox(height: 20,),
              Center(
                child: Text("Trip Managements", style: TextStyle(
                  color: ColorPalette.red,
                  fontSize: 20.0,),),
              ),
              SizedBox(height: 10,),
              Center(
                child: Text("#No 13 East Salemdreishkan Cross Street\nNear Burn Mall, Great Wall\nDubai-630001", style: TextStyle(
                  color: Colors.black87,

                  fontSize: 15.0,),textAlign: TextAlign.center,),

              ),
              SizedBox(height: 30,),
              Center(
                child: Text("erdifny@gmail.com", style: TextStyle(
                  color: Colors.black54,

                  fontSize: 15.0,),textAlign: TextAlign.center,),

              ),





            ],
          ),
        ),

        //  TitleSearch(),
      ]),
    );
  }

}