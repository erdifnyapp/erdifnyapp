
import 'package:flutter/material.dart';

class ToastUtils {

  //ToastUtils.showSuccess("safasfaf");

//  static void showWarning(String message) async {
//    Fluttertoast.showToast(
//        msg: message,
//        toastLength: Toast.LENGTH_LONG,
//        gravity: ToastGravity.BOTTOM,
//        timeInSecForIosWeb: 2,
//        backgroundColor: ColorPalette.red,
//        textColor: Colors.white,
//        fontSize: 12.0
//    );
//  }
//
//  static void showSuccess(String message) async {
//    Fluttertoast.showToast(
//        msg: message,
//        toastLength: Toast.LENGTH_LONG,
//        gravity: ToastGravity.BOTTOM,
//        timeInSecForIosWeb: 2,
//        backgroundColor: Colors.green,
//        textColor: Colors.white,
//        fontSize: 12.0
//    );
//  }
}