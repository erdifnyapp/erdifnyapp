
import 'package:erdifny/utils/const.dart';

class AS {

  static String aaaaa(){
    if(Const.AppLanguage==1){
      return "";
    }else{
      return "";
    }
  }
  //Dashboard
  static String whereareyougoing(){
    if(Const.AppLanguage==1){
      return "إلى أين تذهب ؟";
    }else{
      return "where are you going ?";
    }
  }
  static String Dashbannertitle(){
    if(Const.AppLanguage==1){
      return "تم تحديث عنوان الرسالة أدناه من قبل المسؤول";
    }else{
      return "Title for below Message updated by Admin";
    }
  }
  static String DashbannerDetail(){
    if(Const.AppLanguage==1){
      return "الإمارات العربية المتحدة ، التي تسمى ببساطة الإمارات ، هي دولة تقع في غرب آسيا في الطرف الشمالي الشرقي من شبه الجزيرة العربية على الخليج الفارسي.";
    }else{
      return "The United Arab Emirates, sometimes simply called the Emirates, is a country in Western Asia at the northeast end of the Arabian Peninsula on the Persian Gulf";
    }
  }
  static String TopDistination(){
    if(Const.AppLanguage==1){
      return "أهم الوجهات";
    }else{
      return "Top Destinations";
    }
  }
  static String Whatdoyouwanttosee(){
    if(Const.AppLanguage==1){
      return "تريد أن ترى ما هو متاح بالقرب منك؟";
    }else{
      return "Want to see what's available near you?";
    }
  }
  static String DiscoverAmazing(){
    if(Const.AppLanguage==1){
      return "اكتشف أشياء مذهلة للقيام بها مع Erdisny";
    }else{
      return "Discover amazing things to do with Erdisny dsdg sdgsdg sdgsdgsdg sdgsdgsgd";
    }
  }
  static String ExploreMore(){
    if(Const.AppLanguage==1){
      return "استكشف الآن";
    }else{
      return "Explore Now";
    }
  }

  static String ViewBlog(){
    if(Const.AppLanguage==1){
      return "عرض المدونة";
    }else{
      return "View Blog";
    }
  }

  static String TopAttraction(){
    if(Const.AppLanguage==1){
      return "أعلى مناطق الجذب";
    }else{
      return "Top Attractions";
    }
  }

  static String OurBlog(){
    if(Const.AppLanguage==1){
      return "مدونتنا";
    }else{
      return "Our Blog";
    }
  }

  static String WhatToEnjoyAdvnture(){
    if(Const.AppLanguage==1){
      return "هل تريد الاستمتاع بالمغامرة؟";
    }else{
      return "Want to enjoy Adventure?";
    }
  }
  static String MakeFunWithAdventureRide(){
    if(Const.AppLanguage==1){
      return "استمتع بالركوب بامتياز وضع علامة على الوقت كمعيار";
    }else{
      return "Make fun with advanture ride and mark the time as benchmark";
    }
  }
  static String LatestPackage(){
    if(Const.AppLanguage==1){
      return "أحدث الحزم";
    }else{
      return "Latest Packages";
    }
  }
  static String Reviews(){
    if(Const.AppLanguage==1){
      return "المراجعات";
    }else{
      return "Reviews";
    }
  }
  static String ViewAllPack(){
    if(Const.AppLanguage==1){
      return "عرض جميع الحزم";
    }else{
      return "View All Packages";
    }
  }

  static String ViewAllBlog(){
    if(Const.AppLanguage==1){
      return "عرض كل المدونة";
    }else{
      return "View all Blog";
    }
  }


  static String Explore(){
    if(Const.AppLanguage==1){
      return "استكشف الآن";
    }else{
      return "Explore Now";
    }
  }
  static String Booking(){
    if(Const.AppLanguage==1){
      return "الحجز";
    }else{
      return "Booking";
    }
  }

  static String ReadytoexploreUAE(){
    if(Const.AppLanguage==1){
      return "على استعداد لاستكشاف دولة الإمارات العربية المتحدة";
    }else{
      return "Ready to explore UAE ?";
    }
  }

  static String SelectaDate(){
    if(Const.AppLanguage==1){
      return "حدد التاريخ";
    }else{
      return "Select a Date";
    }
  }


  static String Enjoyourholiday(){
    if(Const.AppLanguage==1){
      return "استمتع بعطلتك";
    }else{
      return "Enjoy your Holiday !";
    }
  }


  static String Saved(){
    if(Const.AppLanguage==1){
      return "تم الحفظ";
    }else{
      return "Saved";
    }
  }
  static String You(){
    if(Const.AppLanguage==1){
      return "أنت";
    }else{
      return "You";
    }
  }

  //BookingScreen
  static String MyBooking(){
    if(Const.AppLanguage==1){
      return "حجوزاتي";
    }else{
      return "My Bookings";
    }
  }
  static String BookingID(){
    if(Const.AppLanguage==1){
      return "معرف الحجز";
    }else{
      return "Booking Id";
    }
  }
  static String Name(){
    if(Const.AppLanguage==1){
      return "اسم";
    }else{
      return "Name";
    }
  }
  static String Email(){
    if(Const.AppLanguage==1){
      return "البريد الإلكتروني";
    }else{
      return "Email";
    }
  }

  static String YourVendorDetail(){
    if(Const.AppLanguage==1){
      return "تفاصيل البائع الخاص بك";
    }else{
      return "Your Vendor Detail";
    }
  }

  static String YourProfileUnderVerify(){
    if(Const.AppLanguage==1){
      return "ملفك الشخصي قيد التحقق. يمكنك الوصول إلى لوحة المورد بعد أن يتحقق المشرف من ملفك الشخصي";
    }else{
      return "Your Profile under verification. You can access vendor panel after admin verify your profile";
    }
  }
  static String Total(){
    if(Const.AppLanguage==1){
      return "مجموع";
    }else{
      return "TOTAL";
    }
  }
  static String Upcoming(){
    if(Const.AppLanguage==1){
      return "القادمة";
    }else{
      return "Upcoming";
    }
  }
  static String PastTrip(){
    if(Const.AppLanguage==1){
      return "الرحلة السابقة";
    }else{
      return "Past Trip";
    }
  }
  static String Person(){
    if(Const.AppLanguage==1){
      return "شخص";
    }else{
      return "Person";
    }
  }
  static String NoTripHistory(){
    if(Const.AppLanguage==1){
      return "لا يوجد تاريخ الرحلة";
    }else{
      return "No Trip History";
    }
  }

  //LikeList
  static String MyFavourite(){
    if(Const.AppLanguage==1){
      return "المفضلة";
    }else{
      return "My Favourites";
    }
  }
  static String Aminity(){
    if(Const.AppLanguage==1){
      return "منشأة";
    }else{
      return "Aminity";
    }
  }
  static String Price(){
    if(Const.AppLanguage==1){
      return "السعر";
    }else{
      return "Price";
    }
  }
  static String Ratings(){
    if(Const.AppLanguage==1){
      return "التقييمات";
    }else{
      return "Ratings";
    }
  }
  static String Category(){
    if(Const.AppLanguage==1){
      return "الفئة";
    }else{
      return "Category";
    }
  }
  static String NoLikeList(){
    if(Const.AppLanguage==1){
      return "لم يتم العثور على قائمة أعجبني";
    }else{
      return "No Like List found";
    }
  }


  //User
  static String MyProfile(){
    if(Const.AppLanguage==1){
      return "ملفي";
    }else{
      return "My Profile";
    }
  }
  static String Bookings(){
    if(Const.AppLanguage==1){
      return "الحجوزات";
    }else{
      return "Bookings";
    }
  }
  static String Wallet(){
    if(Const.AppLanguage==1){
      return "محفظة نقود";
    }else{
      return "Wallet";
    }
  }
  static String Aboutus(){
    if(Const.AppLanguage==1){
      return "معلومات عنا";
    }else{
      return "About us";
    }
  }

  static String Blog(){
    if(Const.AppLanguage==1){
      return "مدونة";
    }else{
      return "Blog";
    }
  }


  static String Help(){
    if(Const.AppLanguage==1){
      return "مساعدة";
    }else{
      return "Help";
    }
  }
  static String WhatsappFaq(){
    if(Const.AppLanguage==1){
      return "الأسئلة الشائعة حول Whatsapp";
    }else{
      return "Whatsapp Faq";
    }
  }
  static String EmailFaq(){
    if(Const.AppLanguage==1){
      return "الأسئلة الشائعة حول البريد الإلكتروني";
    }else{
      return "Email Faq";
    }
  }
  static String ContactFaq(){
    if(Const.AppLanguage==1){
      return "اتصل الأسئلة الشائعة";
    }else{
      return "Contact Faq";
    }
  }
  static String Language(){
    if(Const.AppLanguage==1){
      return "لغة";
    }else{
      return "Language";
    }
  }

  static String Becomeavendor(){
    if(Const.AppLanguage==1){
      return "افتح متجرك في سوق البلد";
    }else{
      return "Become a Vendor";
    }
  }

  static String Company(){
    if(Const.AppLanguage==1){
      return "شركة";
    }else{
      return "Company";
    }
  }

  static String Host(){
    if(Const.AppLanguage==1){
      return "مضيف";
    }else{
      return "Host";
    }
  }

  static String Vendor(){
    if(Const.AppLanguage==1){
      return "بائع";
    }else{
      return "Vendor";
    }
  }

  static String Agent(){
    if(Const.AppLanguage==1){
      return "وكيل";
    }else{
      return "Agent";
    }
  }

  static String Individual(){
    if(Const.AppLanguage==1){
      return "فرد";
    }else{
      return "Individual";
    }
  }


  static String Logout(){
    if(Const.AppLanguage==1){
      return "تسجيل خروج";
    }else{
      return "Logout";
    }
  }

  //ProductListing


  static String Tag(){
    if(Const.AppLanguage==1){
      return "بطاقة شعار";
    }else{
      return "Tag";
    }
  }
  static String Today(){
    if(Const.AppLanguage==1){
      return "اليوم";
    }else{
      return "Today";
    }
  }
  static String Tomorrow(){
    if(Const.AppLanguage==1){
      return "غدا";
    }else{
      return "Tomorrow";
    }
  }

  static String Dated(){
    if(Const.AppLanguage==1){
      return "تاريخ";
    }else{
      return "Date";
    }
  }

  static String AminityFilter(){
    if(Const.AppLanguage==1){
      return "مرشح مرفق";
    }else{
      return "Aminity Filter";
    }
  }
  static String Clear(){
    if(Const.AppLanguage==1){
      return "واضح";
    }else{
      return "Clear";
    }
  }
  static String Apply(){
    if(Const.AppLanguage==1){
      return "تطبيق";
    }else{
      return "Apply";
    }
  }
  static String PriceFilter(){
    if(Const.AppLanguage==1){
      return "تصفية الأسعار";
    }else{
      return "Price Filter";
    }
  }
  static String RatedItems(){
    if(Const.AppLanguage==1){
      return "العناصر المصنفة";
    }else{
      return "Rated Items";
    }
  }
  static String CategoryFilter(){
    if(Const.AppLanguage==1){
      return "تصفية الفئات";
    }else{
      return "Category Filter";
    }
  }
  static String NoPackageFound(){
    if(Const.AppLanguage==1){
      return "لم يتم العثور على حزمة";
    }else{
      return "No Package Found";
    }
  }
  static String ClearFilter(){
    if(Const.AppLanguage==1){
      return "مرشح واضح";
    }else{
      return "Clear Filter";
    }
  }

  static String BookNow(){
    if(Const.AppLanguage==1){
      return "احجز الآن";
    }else{
      return "Book Now";
    }
  }
  static String Cancel(){
    if(Const.AppLanguage==1){
      return "إلغاء";
    }else{
      return "Cancel";
    }
  }
  static String Thisdatecannotbeselected(){
    if(Const.AppLanguage==1){
      return "لا يمكن تحديد هذا التاريخ";
    }else{
      return "This date cannot be selected.";
    }
  }
  static String OK(){
    if(Const.AppLanguage==1){
      return "حسنا";
    }else{
      return "OK";
    }
  }
  static String Dateunavailable(){
    if(Const.AppLanguage==1){
      return "التاريخ غير متاح";
    }else{
      return "Date unavailable";
    }
  }
  static String TRIPAMINITIES(){
    if(Const.AppLanguage==1){
      return "وسائل الراحة";
    }else{
      return "TRIP AMINITIES";
    }
  }
  static String PERSONPERMITTED(){
    if(Const.AppLanguage==1){
      return "الشخص المسموح به";
    }else{
      return "PERSON PERMITTED";
    }
  }
  static String CITIESINCLUDED(){
    if(Const.AppLanguage==1){
      return "المدن المدرجة";
    }else{
      return "CITIES INCLUDED";
    }
  }
  static String MOREABOUT(){
    if(Const.AppLanguage==1){
      return "المزيد عن";
    }else{
      return "MORE ABOUT";
    }
  }
  static String USERREVIEWS(){
    if(Const.AppLanguage==1){
      return "مراجعات المستخدم";
    }else{
      return "USER REVIEWS";
    }
  }
  static String CHILDREN(){
    if(Const.AppLanguage==1){
      return "الأطفال";
    }else{
      return "CHILDREN";
    }
  }
  static String Count(){
    if(Const.AppLanguage==1){
      return "العد";
    }else{
      return "Count :";
    }
  }
  static String ADULT(){
    if(Const.AppLanguage==1){
      return "بالغ";
    }else{
      return "ADULT";
    }
  }
  static String Price2(){
    if(Const.AppLanguage==1){
      return "السعر";
    }else{
      return "Price   :";
    }
  }
  static String Time2(){
    if(Const.AppLanguage==1){
      return "زمن";
    }else{
      return "Time   :";
    }
  }
  static String Meet2(){
    if(Const.AppLanguage==1){
      return "يجتمع";
    }else{
      return "Meet   : ";
    }
  }
  static String ChildrensNotAllowed(){
    if(Const.AppLanguage==1){
      return "لا يسمح للأطفال";
    }else{
      return "Childrens Not Allowed";
    }
  }
  static String Minimum(){
    if(Const.AppLanguage==1){
      return "الحد الأدنى";
    }else{
      return "Minimum";
    }
  }

  static String Maximum(){
    if(Const.AppLanguage==1){
      return "أقصى";
    }else{
      return "Maximum";
    }
  }
  static String AdultNotAllowed(){
    if(Const.AppLanguage==1){
      return "الكبار غير مسموح لهم";
    }else{
      return "Adult Not Allowed";
    }
  }
  static String CheckOut(){
    if(Const.AppLanguage==1){
      return "الدفع";
    }else{
      return "Check Out";
    }
  }
  static String MAPLOCATION(){
    if(Const.AppLanguage==1){
      return "خريطة الموقع";
    }else{
      return "MAP LOCATION";
    }
  }

  static String ConformBooking(){
    if(Const.AppLanguage==1){
      return "الموافقة على الحجز";
    }else{
      return "Conform Booking";
    }
  }
  static String Members(){
    if(Const.AppLanguage==1){
      return "أفراد";
    }else{
      return "Members";
    }
  }
  static String Child(){
    if(Const.AppLanguage==1){
      return "طفل";
    }else{
      return "Child";
    }
  }

  static String SelectPaymentMethod(){
    if(Const.AppLanguage==1){
      return "اختار طريقة الدفع";
    }else{
      return "Select Payment Method";
    }
  }

  static String Childrens(){
    if(Const.AppLanguage==1){
      return "أطفال";
    }else{
      return "Childrens";
    }
  }
  static String AdultCost(){
    if(Const.AppLanguage==1){
      return "تكلفة الكبار";
    }else{
      return "Adult Cost";
    }
  }
  static String ChildCost(){
    if(Const.AppLanguage==1){
      return "تكلفة الطفل";
    }else{
      return "Child Cost";
    }
  }
  static String TOTALCOST(){
    if(Const.AppLanguage==1){
      return "التكلفة الإجمالية";
    }else{
      return "TOTAL COST";
    }
  }
  static String TOTAL(){
    if(Const.AppLanguage==1){
      return "مجموع";
    }else{
      return "TOTAL";
    }
  }
  static String NumberOfTravellers(){
    if(Const.AppLanguage==1){
      return "عدد المسافرين";
    }else{
      return "Number Of Travellers";
    }
  }
  static String Adult(){
    if(Const.AppLanguage==1){
      return "بالغ";
    }else{
      return "Adult";
    }
  }

  static String CostSummary(){
    if(Const.AppLanguage==1){
      return "ملخص التكلفة";
    }else{
      return "Cost Summary";
    }
  }
  static String TripNote(){
    if(Const.AppLanguage==1){
      return "ملاحظة الرحلة";
    }else{
      return "Trip Note";
    }
  }
  static String AddNote(){
    if(Const.AppLanguage==1){
      return "اضف ملاحظة";
    }else{
      return "Add Note";
    }
  }

  //My Profile

  static String Userinformation(){
    if(Const.AppLanguage==1){
      return "معلومات المستخدم";
    }else{
      return "User information";
    }
  }
  static String Phone(){
    if(Const.AppLanguage==1){
      return "هاتف";
    }else{
      return "Phone";
    }
  }
  static String EditProfile(){
    if(Const.AppLanguage==1){
      return "تعديل الملف الشخصي";
    }else{
      return "Edit Profile";
    }
  }

  static String Pleasefillalldetails(){
    if(Const.AppLanguage==1){
      return "يرجى ملء جميع التفاصيل";
    }else{
      return "Please fill all details";
    }
  }
  static String YourName(){
    if(Const.AppLanguage==1){
      return "اسمك";
    }else{
      return "Your Name";
    }
  }

  static String CompanyName(){
    if(Const.AppLanguage==1){
      return "اسم الشركة";
    }else{
      return "Company Name";
    }
  }

  static String YourCompanyName(){
    if(Const.AppLanguage==1){
      return "اسم شركتك ";
    }else{
      return "Your Company Name";
    }
  }

  static String LableName(){
    if(Const.AppLanguage==1){
      return "اسم الطابع";
    }else{
      return "Lable Name";
    }
  }

  static String CompanyOrIndividual(){
    if(Const.AppLanguage==1){
      return "اسم الشركة أو الفرد";
    }else{
      return "Company or Individual Lable";
    }
  }

  static String Save(){
    if(Const.AppLanguage==1){
      return "حفظ";
    }else{
      return "Save";
    }
  }
  static String Camera(){
    if(Const.AppLanguage==1){
      return "الة تصوير";
    }else{
      return "Camera";
    }
  }
  static String Gallery(){
    if(Const.AppLanguage==1){
      return "صالة عرض";
    }else{
      return "Gallery";
    }
  }
  static String MyWallet(){
    if(Const.AppLanguage==1){
      return "محفظتي";
    }else{
      return "My Wallet";
    }
  }
  static String YourErdifnyWalletBalance(){
    if(Const.AppLanguage==1){
      return "رصيدك في محفظة Erdifny";
    }else{
      return "Your Erdifny Wallet Balance";
    }
  }
  static String AddBalance(){
    if(Const.AppLanguage==1){
      return "أضف رصيدًا";
    }else{
      return "Add Balance";
    }
  }
  static String Howmuchamount(){
    if(Const.AppLanguage==1){
      return "كم المبلغ";
    }else{
      return "How much amount";
    }
  }
  static String Amount(){
    if(Const.AppLanguage==1){
      return "كمية";
    }else{
      return "Amount";
    }
  }

  static String AreyouSureLogout(){
    if(Const.AppLanguage==1){
      return "هل أنت متأكد من أنك تريد تسجيل الخروج؟ سيتم حذف جميع البيانات في حسابك. يرجى التوافق الآن";
    }else{
      return "Are you sure want to logout? All data in your account will get deleted. Please conform now";
    }
  }

  static String aaa(){
    if(Const.AppLanguage==1){
      return "";
    }else{
      return "";
    }
  }
  static String Youremail(){
    if(Const.AppLanguage==1){
      return "بريدك الالكتروني";
    }else{
      return "Your email";
    }
  }
  static String YourPassword(){
    if(Const.AppLanguage==1){
      return "كلمتك السرية";
    }else{
      return "Your Password";
    }
  }
  static String Password(){
    if(Const.AppLanguage==1){
      return "كلمه السر";
    }else{
      return "Password";
    }
  }
  static String LoginNow(){
    if(Const.AppLanguage==1){
      return "تسجيل الدخول الآن";
    }else{
      return "Login Now";
    }
  }
  static String Register(){
    if(Const.AppLanguage==1){
      return "تسجيل";
    }else{
      return "Register";
    }
  }

  static String YourPhone(){
    if(Const.AppLanguage==1){
      return "Your Phone";
    }else{
      return "هاتفك";
    }
  }
  static String RetypePassword(){
    if(Const.AppLanguage==1){
      return "اعد كتابة كلمة المرور";
    }else{
      return "Retype Password";
    }
  }
  static String ConformPassword(){
    if(Const.AppLanguage==1){
      return "مطابقة كلمة المرور";
    }else{
      return "Conform Password";
    }
  }
  static String RegisterNow(){
    if(Const.AppLanguage==1){
      return "سجل الان";
    }else{
      return "Register Now";
    }
  }
  static String Login(){
    if(Const.AppLanguage==1){
      return "تسجيل الدخول";
    }else{
      return "Login";
    }
  }

  static String BookingDetail(){
    if(Const.AppLanguage==1){
      return "تفاصيل الحجز";
    }else{
      return "Booking Detail";
    }
  }
  static String TotalPerson(){
    if(Const.AppLanguage==1){
      return "إجمالي الشخص";
    }else{
      return "Total Person  ";
    }
  }
  static String PricePaidforAdult(){
    if(Const.AppLanguage==1){
      return "السعر المدفوع للبالغين";
    }else{
      return "Price Paid for Adult";
    }
  }
  static String PricePaidforChild(){
    if(Const.AppLanguage==1){
      return "السعر المدفوع للطفل";
    }else{
      return "Price Paid for Child";
    }
  }
  static String TotalPaid(){
    if(Const.AppLanguage==1){
      return "مجموع المبالغ المدفوعة";
    }else{
      return "Total Paid";
    }
  }
  static String Paid(){
    if(Const.AppLanguage==1){
      return "دفع";
    }else{
      return "Paid";
    }
  }
  static String TripDate(){
    if(Const.AppLanguage==1){
      return "تاريخ الرحلة";
    }else{
      return "Trip Date";
    }
  }
  static String Duration(){
    if(Const.AppLanguage==1){
      return "المدة الزمنية";
    }else{
      return "Duration";
    }
  }
  static String MeetingPoint(){
    if(Const.AppLanguage==1){
      return "نقطة إلتقاء";
    }else{
      return "Meeting Point";
    }
  }
  static String BookingNote(){
    if(Const.AppLanguage==1){
      return "مذكرة الحجز";
    }else{
      return "Booking Note";
    }
  }
  static String YourReview(){
    if(Const.AppLanguage==1){
      return "مراجعتك";
    }else{
      return "Your Review";
    }
  }
  static String WriteYourReview(){
    if(Const.AppLanguage==1){
      return "اكتب مراجعتك";
    }else{
      return "Write Your Review";
    }
  }
  static String Scaleyourrating(){
    if(Const.AppLanguage==1){
      return "قم بقياس تقييمك من 0 إلى 5";
    }else{
      return "Scale your rating 0 to 5";
    }
  }
  static String Review(){
    if(Const.AppLanguage==1){
      return "مراجعة";
    }else{
      return "Review";
    }
  }
  static String Summit(){
    if(Const.AppLanguage==1){
      return "قمة";
    }else{
      return "Summit";
    }
  }
  static String Languages(){
    if(Const.AppLanguage==1){
      return "اللغات";
    }else{
      return "Languages";
    }
  }

  static String Arabic(){
    if(Const.AppLanguage==1){
      return "عربى";
    }else{
      return "Arabic";
    }
  }

  static String FromWallet(){
    if(Const.AppLanguage==1){
      return "من المحفظة";
    }else{
      return "From wallet";
    }
  }
  static String FromPaymentPortal(){
    if(Const.AppLanguage==1){
      return "من بوابة الدفع";
    }else{
      return "From payment portal";
    }
  }
}