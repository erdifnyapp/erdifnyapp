class Urls{

//  static var iP="http://192.168.43.116/";
//  static var iP="http://192.168.225.101/";
//  static var imageLocation=iP+"FlutterProjects/Erdifny/Site/API/mec/";
//  static var address=iP+"FlutterProjects/Erdifny/Site/API/admin/mobile_api/";
//  static var WebviewforNews=iP+"FlutterProjects/Erdifny/Site/API/admin/webviews.php";

  static var iP="http://139.59.15.12/API/";
  static var imageLocation=iP+"mec/";
  static var address=iP+"admin/mobile_api/";
  static var WebviewforNews=iP+"admin/webviews.php";

  static var DummyImageBanner="assets/images/logoban.jpg";

  static var login=address+"login.php";
  static var register=address+"registration.php";
  static var sociallogin=address+"social_registration.php";
  static var VendorRegister=address+"vendor-reg.php";
  static var validation=address+"validation.php";
  static var Dashboard=address+"dashboard.php";
  static var ProductView=address+"product-view.php";
  static var AddLike=address+"add_like.php";
  static var PackList=address+"pack-list.php";
  static var LikeList=address+"like-list.php";
  static var AddBookingWallet=address+"add-booking-wallet.php";
  static var AddBookingPortal=address+"add-booking-portal.php";
  static var ViewBooking=address+"booking-list.php";
  static var BookingView=address+"booking-view.php";
  static var AddReview=address+"add-review.php";
  static var UpdateUser=address+"update.php";
  static var UpdateImage=address+"update-image.php";
  static var HelpPage=address+"help-page.php";
  static var Filters=address+"filters.php";
  static var Wallet=address+"wallet-list.php";
  static var AddWallet=address+"add-wallet.php";
  static var BlogList=address+"blog-list.php";
  static var BlogView=address+"blog-view.php";
  static var VendorView=address+"view-vendor.php";

}